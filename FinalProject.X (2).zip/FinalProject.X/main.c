 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include <stdlib.h>
#include <stdio.h>

/*
Sounds

const unsigned char Sine32_4Bits[32] = {8,9,11,12,13,14,15,15,15,15,14,14,13,11,10,9,7,6,4,3,2,1,0,0,0,0,1,1,2,4,5,6};
const unsigned char Bassoon[64] =
{14,16,16,16,16,16,16,16,14,14,12,14,16,20,28,31,24,14,4,0,0,4,6,10,14,18,22,22,20,18,14,10,6,4,4,6,10,14,18,20,18,14,12,10,10,10,10,10,12,12,14,14,14,16,16,18,18,16,16,16,16,16,14,14};
const unsigned char Flute[64] =
{11,13,15,17,20,22,24,26,28,29,30,31,31,31,30,29,27,25,23,21,19,17,15,14,13,12,11,10,10,9,9,8,8,8,7,7,7,6,6,6,5,5,4,4,3,3,2,2,1,1,0,0,0,0,1,1,2,2,3,4,5,6,7,9};
const unsigned char Guitar[64] =
{11,11,10,9,8,6,3,1,0,1,4,8,14,18,21,23,24,23,21,16,12,6,4,4,6,12,18,24,29,31,29,24,20,16,14,12,11,10,10,10,11,13,15,16,16,16,15,12,10,6,5,4,5,6,6,6,6,6,7,8,9,10,11,11};
const unsigned char Trumpet[64] =
{20,20,21,22,23,24,24,23,22,20,16,11,6,2,0,2,7,17,24,30,31,29,25,22,20,20,20,21,21,21,20,19,19,20,20,19,18,18,18,19,20,21,21,21,20,20,20,20,20,21,21,21,21,21,21,20,20,19,19,18,18,19,19,20};
const unsigned char Zeros[64]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
*/

const unsigned char Inst[5][64]={{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},{11,11,10,9,8,6,3,1,0,1,4,8,14,18,21,23,24,23,21,16,12,6,4,4,6,12,18,24,29,31,29,24,20,16,14,12,11,10,10,10,11,13,15,16,16,16,15,12,10,6,5,4,5,6,6,6,6,6,7,8,9,10,11,11},{11,13,15,17,20,22,24,26,28,29,30,31,31,31,30,29,27,25,23,21,19,17,15,14,13,12,11,10,10,9,9,8,8,8,7,7,7,6,6,6,5,5,4,4,3,3,2,2,1,1,0,0,0,0,1,1,2,2,3,4,5,6,7,9},{14,16,16,16,16,16,16,16,14,14,12,14,16,20,28,31,24,14,4,0,0,4,6,10,14,18,22,22,20,18,14,10,6,4,4,6,10,14,18,20,18,14,12,10,10,10,10,10,12,12,14,14,14,16,16,18,18,16,16,16,16,16,14,14},{20,21,22,23,24,24,23,22,20,16,11,6,2,0,2,7,17,24,30,31,29,25,22,20,20,20,21,21,21,20,19,19,20,20,19,18,18,18,19,20,21,21,21,20,20,20,20,20,21,21,21,21,21,21,20,20,19,19,18,18,19,19,20}};

unsigned short delay2=313; //312.5=(1/50)/64, rounded up, in us
unsigned char delay1=5; //4.88=(1/3200)/64, rounded down, in us

struct State {
  uint16_t G_sound;
  uint16_t F_sound;
  uint16_t B_sound;
  uint16_t T_sound;
  uint16_t PlayNo;
  uint16_t Next[32];}; // next state for inputs 0,1,2,3,4,5,6,7,...
typedef const struct State STyp;
#define None  0
#define Gplay 1
#define Ghold 2
#define Fplay 3
#define Fhold 4
#define Bplay 5
#define Bhold 6
#define Tplay 7
#define Thold 8
#define Ghold_Fplay 9
#define Ghold_Tplay 10
#define Ghold_Bplay 11
#define Fhold_Gplay 12
#define Fhold_Tplay 13
#define Fhold_Bplay 14
#define Bhold_Gplay 15
#define Bhold_Fplay 16
#define Bhold_Tplay 17
#define Thold_Gplay 18
#define Thold_Fplay 19
#define Thold_Bplay 20
#define GFhold 21
#define BFhold 22
#define TFhold 23
#define GThold 24
#define GBhold 25
#define BThold 26
#define GFhold_Tplay 27
#define GFhold_Bplay 28
#define BFhold_Gplay 29
#define BFhold_Tplay 30
#define TFhold_Gplay 31
#define TFhold_Bplay 32
#define GThold_Fplay 33
#define GThold_Bplay 34
#define GBhold_Fplay 35
#define GBhold_Tplay 36
#define BThold_Gplay 37
#define BThold_Fplay 38
#define GFBhold 39
#define GFThold 40
#define GTBhold 41
#define TFBhold 42
STyp FSM[43]={
 {0,0,0,0,0,{None,None,None,None,Gplay,Ghold,None,None,Fplay,Fhold,None,None,Tplay,Thold,None,None,Bplay,Bhold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None}}, 
 {1,0,0,0,1,{None,Ghold,None,None,Gplay,Ghold,None,None,Fplay,Fhold,None,None,Tplay,Thold,None,None,Bplay,Bhold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None}},
 {1,0,0,0,0,{Ghold,Ghold,None,None,Ghold,Ghold,None,None,Ghold_Fplay,GFhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Bplay,GBhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None}},
 {0,1,0,0,2,{None,Fhold,None,None,Gplay,Ghold,None,None,Fplay,Fhold,None,None,Tplay,Thold,None,None,Bplay,Bhold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None}},
 {0,1,0,0,0,{Fhold,Fhold,None,None,Fhold_Gplay,GFhold,None,None,Fhold,Fhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Bplay,BFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None}},
 {0,0,1,0,3,{None,Bhold,None,None,Gplay,Ghold,None,None,Fplay,Fhold,None,None,Tplay,Thold,None,None,Bplay,Bhold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None}},
 {0,0,1,0,0,{Bhold,Bhold,None,None,Bhold_Gplay,GBhold,None,None,Bhold_Fplay,BFhold,None,None,Bhold_Tplay,BThold,None,None,Bhold,Bhold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None}},
 {0,0,0,1,4,{None,Thold,None,None,Gplay,Ghold,None,None,Fplay,Fhold,None,None,Tplay,Thold,None,None,Bplay,Bhold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None,Tplay,Thold,None,None}},
 {0,0,0,1,0,{Thold,Thold,None,None,Thold_Gplay,GThold,None,None,Thold_Fplay,TFhold,None,None,Thold,Thold,None,None,Thold_Bplay,BThold,None,None,Thold,Thold,None,None,Thold,Thold,None,None,Thold,Thold,None,None}},
 {1,1,0,0,2,{Ghold,GFhold,None,None,Ghold,Ghold,None,None,Ghold_Fplay,GFhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Bplay,GBhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None}},
 {1,0,0,1,4,{Ghold,GThold,None,None,Ghold,Ghold,None,None,Ghold_Fplay,GFhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Bplay,GBhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None}},
 {1,0,1,0,3,{Ghold,GBhold,None,None,Ghold,Ghold,None,None,Ghold_Fplay,GFhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Bplay,GBhold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None,Ghold_Tplay,GThold,None,None}},
 {1,1,0,0,1,{Fhold,GFhold,None,None,Fhold_Gplay,GFhold,None,None,Fhold,Fhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Bplay,BFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None}},
 {0,1,0,1,4,{Fhold,TFhold,None,None,Fhold_Gplay,GFhold,None,None,Fhold,Fhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Bplay,BFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None}},
 {0,1,1,0,3,{Fhold,BFhold,None,None,Fhold_Gplay,GFhold,None,None,Fhold,Fhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Bplay,BFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None,Fhold_Tplay,TFhold,None,None}},
 {1,0,1,0,1,{Bhold,GBhold,None,None,Bhold_Gplay,GBhold,None,None,Bhold_Fplay,BFhold,None,None,Bhold_Tplay,BThold,None,None,Bhold,Bhold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None}},
 {0,1,1,0,2,{Bhold,BFhold,None,None,Bhold_Gplay,GBhold,None,None,Bhold_Fplay,BFhold,None,None,Bhold_Tplay,BThold,None,None,Bhold,Bhold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None}},
 {0,0,1,1,4,{Bhold,BThold,None,None,Bhold_Gplay,GBhold,None,None,Bhold_Fplay,BFhold,None,None,Bhold_Tplay,BThold,None,None,Bhold,Bhold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None,Bhold_Tplay,BThold,None,None}},
 {1,0,0,1,1,{Thold,GThold,None,None,Thold_Gplay,GThold,None,None,Thold_Fplay,TFhold,None,None,Thold,Thold,None,None,Thold_Bplay,BThold,None,None,Thold,Thold,None,None,Thold,Thold,None,None,Thold,Thold,None,None}},
 {0,1,0,1,2,{Thold,TFhold,None,None,Thold_Gplay,GThold,None,None,Thold_Fplay,TFhold,None,None,Thold,Thold,None,None,Thold_Bplay,BThold,None,None,Thold,Thold,None,None,Thold,Thold,None,None,Thold,Thold,None,None}},
 {0,0,1,1,3,{Thold,BThold,None,None,Thold_Gplay,GThold,None,None,Thold_Fplay,TFhold,None,None,Thold,Thold,None,None,Thold_Bplay,BThold,None,None,Thold,Thold,None,None,Thold,Thold,None,None,Thold,Thold,None,None}},
 {1,1,0,0,0,{GFhold,GFhold,None,None,GFhold,GFhold,None,None,GFhold,GFhold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Bplay,GFBhold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Tplay,GFThold,None,None}},
 {0,1,1,0,0,{BFhold,BFhold,None,None,BFhold_Gplay,GFBhold,None,None,BFhold,BFhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold,BFhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold_Tplay,TFBhold,None,None}},
 {0,1,0,1,0,{TFhold,TFhold,None,None,TFhold_Gplay,GFThold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None,TFhold_Bplay,TFBhold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None}},
 {1,0,0,1,0,{GThold,GThold,None,None,GThold,GThold,None,None,GThold_Fplay,GFThold,None,None,GThold,GThold,None,None,GThold_Bplay,GTBhold,None,None,GThold,GThold,None,None,GThold,GThold,None,None,GThold,GThold,None,None}},
 {1,0,1,0,0,{GBhold,GBhold,None,None,GBhold,GBhold,None,None,GBhold_Fplay,GFBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold,GBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold_Tplay,GTBhold,None,None}},
 {0,0,1,1,0,{BThold,BThold,None,None,BThold_Gplay,GTBhold,None,None,BThold_Fplay,TFBhold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None}},
 {1,1,0,1,4,{GFhold,GFThold,None,None,GFhold,GFhold,None,None,GFhold,GFhold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Bplay,GFBhold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Tplay,GFThold,None,None}},
 {1,1,1,0,3,{GFhold,GFBhold,None,None,GFhold,GFhold,None,None,GFhold,GFhold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Bplay,GFBhold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Tplay,GFThold,None,None,GFhold_Tplay,GFThold,None,None}},
 {1,1,1,0,1,{BFhold,GFBhold,None,None,BFhold_Gplay,GFBhold,None,None,BFhold,BFhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold,BFhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold_Tplay,TFBhold,None,None}},
 {0,1,1,1,4,{BFhold,TFBhold,None,None,BFhold_Gplay,GFBhold,None,None,BFhold,BFhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold,BFhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold_Tplay,TFBhold,None,None,BFhold_Tplay,TFBhold,None,None}},
 {1,1,0,1,1,{TFhold,GFThold,None,None,TFhold_Gplay,GFThold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None,TFhold_Bplay,TFBhold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None}},
 {0,1,1,1,3,{TFhold,TFBhold,None,None,TFhold_Gplay,GFThold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None,TFhold_Bplay,TFBhold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None,TFhold,TFhold,None,None}},
 {1,1,0,1,2,{GThold,GFThold,None,None,GThold,GThold,None,None,GThold_Fplay,GFThold,None,None,GThold,GThold,None,None,GThold_Bplay,GTBhold,None,None,GThold,GThold,None,None,GThold,GThold,None,None,GThold,GThold,None,None}},
 {1,0,1,1,3,{GThold,GTBhold,None,None,GThold,GThold,None,None,GThold_Fplay,GFThold,None,None,GThold,GThold,None,None,GThold_Bplay,GTBhold,None,None,GThold,GThold,None,None,GThold,GThold,None,None,GThold,GThold,None,None}},
 {1,1,1,0,2,{GBhold,GFBhold,None,None,GBhold,GBhold,None,None,GBhold_Fplay,GFBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold,GBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold_Tplay,GTBhold,None,None}},
 {1,0,1,1,4,{GBhold,GTBhold,None,None,GBhold,GBhold,None,None,GBhold_Fplay,GFBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold,GBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold_Tplay,GTBhold,None,None,GBhold_Tplay,GTBhold,None,None}},
 {1,0,1,1,1,{BThold,GTBhold,None,None,BThold_Gplay,GTBhold,None,None,BThold_Fplay,TFBhold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None}},
 {0,1,1,1,2,{BThold,TFBhold,None,None,BThold_Gplay,GTBhold,None,None,BThold_Fplay,TFBhold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None,BThold,BThold,None,None}},
 {1,1,1,0,0,{GFBhold,GFBhold,None,None,GFBhold,GFBhold,None,None,GFBhold,GFBhold,None,None,GFBhold,GFBhold,None,None,GFBhold,GFBhold,None,None,GFBhold,GFBhold,None,None,GFBhold,GFBhold,None,None,GFBhold,GFBhold,None,None}},
 {1,1,0,1,0,{GFThold,GFThold,None,None,GFThold,GFThold,None,None,GFThold,GFThold,None,None,GFThold,GFThold,None,None,GFThold,GFThold,None,None,GFThold,GFThold,None,None,GFThold,GFThold,None,None,GFThold,GFThold,None,None}},
 {1,0,1,1,0,{GTBhold,GTBhold,None,None,GTBhold,GTBhold,None,None,GTBhold,GTBhold,None,None,GTBhold,GTBhold,None,None,GTBhold,GTBhold,None,None,GTBhold,GTBhold,None,None,GTBhold,GTBhold,None,None,GTBhold,GTBhold,None,None}},
 {0,1,1,1,0,{TFBhold,TFBhold,None,None,TFBhold,TFBhold,None,None,TFBhold,TFBhold,None,None,TFBhold,TFBhold,None,None,TFBhold,TFBhold,None,None,TFBhold,TFBhold,None,None,TFBhold,TFBhold,None,None,TFBhold,TFBhold,None,None}}
 
};


volatile uint16_t Val1;
volatile uint16_t Val2;
volatile uint16_t Val3;
volatile uint16_t Ind1;
volatile uint16_t Ind2;
volatile uint16_t Ind3;
volatile uint16_t f1,f2,f3;
volatile uint16_t IndDAC,ValDAC,delay_DAC;

void myTimer0ISR(void){
    
}

uint16_t CurrState; 
uint16_t Input; 

void main(void) {
    f1=delay1;
    f2=delay1;
    f3=delay1;
    
    
    uint16_t sound1,sound2,sound3;
    sound1=0;
    sound2=0;
    sound3=0;
    
    
  CurrState = None;
    SYSTEM_Initialize();
    TMR0_OverflowCallbackRegister(myTimer0ISR);    
   
    TMR0_Start();   
    
    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();
   
    uint16_t A,B,C,D;
    A=0;
    B=0;
    C=0;
    D=0;
    
    while (1) {
    uint16_t valFromADC = ADC_ChannelSelectAndConvert(0);
    uint16_t prop_ADC=(valFromADC>>4)+(valFromADC>>6);
    delay_DAC=(prop_ADC)+delay1;   
    
    Ind1=0;
    Ind2=0;
    Ind3=0;
    IndDAC=0;
    Val1=0;
    Val2=0;
    Val3=0;
    ValDAC=0;
        
    Input=PORTD;
    
    unsigned int a,b,c,d,e;
    a=FSM[CurrState].G_sound;
    b=FSM[CurrState].F_sound;
    c=FSM[CurrState].B_sound;
    d=FSM[CurrState].T_sound;
    e=a+b+c+d;
    
    
    if(CurrState!=FSM[CurrState].Next[Input]){
        if(IO_RD0_GetValue()==1){
            if(e==1){
                f1=delay_DAC;
                if(a==1){
                    sound1=1;
                }
                else if (b==1){
                    sound1=2;
                }
                else if (c==1){
                    sound1=3;
                }
                else sound1=4;
            }
            else if (e==2){
                f2=delay_DAC;
                if (a==1&&sound1!=1){
                    sound2=1;
                }
                else if (b==1&&sound1!=2){
                    sound2=2;
                }
                else if (c==1&&sound1!=3){
                    sound2=1;
                }
                else sound2=4;
            }
            else if (e==3){
                f3=delay_DAC;
                if (a==1&&sound1!=1&&sound2!=1){
                    sound3=1;
                }
                else if (b==1&&sound1!=2&&sound2!=2){
                    sound3=2;
                }
                else if (c==1&&sound1!=3&&sound2!=3){
                    sound3=3;
                }
                else sound3=4;
            }
        }
    }
    
    CurrState = FSM[CurrState].Next[Input];
    
    uint16_t play=FSM[CurrState].PlayNo;
    uint16_t max;
    if (f1>f2&&f1>f3&&f1>delay_DAC){
        max=f1;
    }
    else if (f2>f1&&f2>f3&&f2>delay_DAC){
        max=f2;
    }
    else if (f3>f1&&f3>f2&&f3>delay_DAC){
        max=f3;
    }
    else if (play!=0) max=delay_DAC;
    
  
    uint16_t i=0; 
    
    if (CurrState==None){
        f1=delay1;
        f2=delay1;
        f3=delay1;
        sound1=0;
        sound2=0;
        sound3=0;
    }

    
    for (i=0; i<(max*delay2); i++){
    Ind1++;
    Ind2++;
    Ind3++;
    IndDAC++;
    if (Ind1>=f1){
        Val1++;
        Ind1=0;
    }
    if (Ind2>=f2){
        Val2++;
        Ind2=0;
    }
    if (Ind3>=f3){
        Val3++;
        Ind3=0;
    }
     if (IndDAC>=delay_DAC){
        ValDAC++;
        IndDAC=0;
    }
        A=Inst[sound1][Val1];
        B=Inst[sound2][Val2];
        C=Inst[sound3][Val3];
        D=Inst[play][ValDAC];
        IO_RA2_PORT=A+B+C+D;
        
     if (Val1==63){
            Val1=0;
        }
        if (Val2==63){
            Val2=0;
        }
        if (Val3==63){
            Val3=0;
        }
        if (ValDAC==63){
            ValDAC=0;
        }
        
        INTERRUPT_GlobalInterruptDisable();
        INTERRUPT_GlobalInterruptEnable();  
    }

        }
        
    }
